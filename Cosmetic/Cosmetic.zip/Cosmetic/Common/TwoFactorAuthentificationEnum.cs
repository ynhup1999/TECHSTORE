using System;
using System.Collections.Generic;
using System.Text;

namespace EC.SecurityService.Common
{
    public enum TwoFactorAuthentificationEnum
    {
        SMS,
        EMAIL
    }
}