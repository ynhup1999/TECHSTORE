﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cosmetic.Models
{
    public class RestoreAccount
    {
        public string UserEmail { set; get; }
    }
}
