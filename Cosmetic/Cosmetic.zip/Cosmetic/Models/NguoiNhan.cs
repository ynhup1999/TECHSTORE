﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Cosmetic.Models
{
    public class NguoiNhan
    {
        public string TenNhan { get; set; }
        public string DiaChiNhan { get; set; }
        public string SDTNhan { get; set; }
        public string GhiChu { get; set; }
    }
}
